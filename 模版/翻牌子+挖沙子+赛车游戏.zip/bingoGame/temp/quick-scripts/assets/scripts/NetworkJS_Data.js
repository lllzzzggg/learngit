(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/NetworkJS_Data.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '8febaBdc6ZNMK6NnHe3UpZb', 'NetworkJS_Data', __filename);
// scripts/NetworkJS_Data.js

"use strict";

var NetworkJS = require("NetworkJS");

cc.Class({
	extends: NetworkJS,

	properties: {},

	//解析转换每一条数据
	analysisDict: function analysisDict(questionDict) {
		var interactiveJson = questionDict.interactiveJson;
		if (!interactiveJson || interactiveJson.length == 0) {
			//容错不录json的情况
			this.gameLoadFailed(2);
			return;
		} else if (typeof interactiveJson == 'string') {
			interactiveJson = JSON.parse(interactiveJson);
		}

		var answerArr = interactiveJson.answerArr;
		var questionArr = interactiveJson.questionArr;

		var imgUrlsArr = interactiveJson.image;

		cc.log("imgUrlsArr: " + imgUrlsArr);
		//每一道小题内容
		var question = {
			answerTime: '0', //答题时间
			levelQuestionDetailID: questionDict.questionid, //IPS题目（小题） ID
			leveLQuestionDetailNum: questionDict.orderid, //IPS题目（小题）序号
			qescont: this.removeSpan(questionDict.qescont), //题干
			interactiveJson: interactiveJson //格外配置json
		};
		return question;
	}
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=NetworkJS_Data.js.map
        