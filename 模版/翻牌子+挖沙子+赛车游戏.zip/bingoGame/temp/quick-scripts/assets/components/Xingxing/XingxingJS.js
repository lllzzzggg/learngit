(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/components/Xingxing/XingxingJS.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'ea220VjaTtGaLQzyud5gsYc', 'XingxingJS', __filename);
// components/Xingxing/XingxingJS.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // use this for initialization
    onLoad: function onLoad() {
        this.node.scale = Math.random();
        //运行动画
        this.node.runAction(cc.sequence(cc.spawn(cc.moveBy(0.5, cc.p(280 * (Math.random() * 2 - 1), 280 * (Math.random() * 2 - 1))), cc.scaleTo(0.5, Math.random() * 0.5 + 0.5), cc.rotateBy(0.5, Math.random() * 90)), cc.callFunc(function () {
            this.node.active = false;
        }, this)));
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=XingxingJS.js.map
        