"use strict";
cc._RF.push(module, '796e7zU0VtNvZXCnNmyhJQK', 'Help');
// scripts/Help.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {},

    // use this for initialization
    onLoad: function onLoad() {
        this.scheduleOnce(function () {
            cc.director.loadScene('WordRace');
        }, 3);
    }
});

cc._RF.pop();