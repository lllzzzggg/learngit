(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/Config.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '55a24YSwX9IIKdwgTK8Lrpl', 'Config', __filename);
// scripts/Config.js

'use strict';

//log日志开关
window.CONSOLE_LOG_OPEN = true;

//自定义跳转开关
window.OPTION_BLANK = true;

//注册监听home键事件
document.addEventListener('resignActivePauseGame', function () {
    cc.director.pause();
    cc.game.pause();

    console.log('app just resign active.');
});
document.addEventListener('becomeActiveResumeGame', function () {
    if (cc.game.isPaused) {
        cc.game.resume();
    }
    if (cc.director.isPaused) {
        cc.director.resume();
    }
    console.log('app just become active.');
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Config.js.map
        