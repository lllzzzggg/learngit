(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/GameStart.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'c8b37JrgftHIqtBJYwPmFST', 'GameStart', __filename);
// scripts/GameStart.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {
        gameData: cc.Node
    },

    // use this for initialization
    onLoad: function onLoad() {
        cc.game.addPersistRootNode(this.gameData);
    },

    startClick: function startClick() {
        cc.director.loadScene('ShowWord');
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=GameStart.js.map
        