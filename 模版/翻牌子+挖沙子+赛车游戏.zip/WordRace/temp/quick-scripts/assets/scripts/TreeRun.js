(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/TreeRun.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'bae332o3LpHm7DaMzrERItV', 'TreeRun', __filename);
// scripts/TreeRun.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {},

    // use this for initialization
    treeStartRun: function treeStartRun() {
        for (var index = 1; index <= 9; index++) {
            this.treeRunAnim(index);
        }
    },

    treeRunAnim: function treeRunAnim(index) {
        var treeName = 'Tree' + index;
        var treeNode = this.node.getChildByName(treeName);
        // treeNode.active = true;
        if (treeNode.activeInHierarchy) {
            treeNode.getComponent(cc.Animation).play(treeName, index * 0.2);
        }
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=TreeRun.js.map
        