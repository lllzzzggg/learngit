(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/WordManager.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '383d8II9etMzodryl8HuXbE', 'WordManager', __filename);
// scripts/WordManager.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {},

    // use this for initialization
    onLoad: function onLoad() {},

    showWordImage: function showWordImage(target, optionsArr, runTime) {
        this.target = target;

        for (var index = 0; index < this.node.children.length; index++) {
            var element = this.node.children[index];
            element.opacity = 0;
            if (optionsArr[index]) {
                var word = optionsArr[index].optioncontimg;
                if (word) {
                    this.loadWordImage(element, word);
                }
            }
        }
        var animState = this.node.getComponent(cc.Animation).play();
        animState.speed = animState.duration / runTime;
    },

    loadWordImage: function loadWordImage(wordNode, wordUrl) {
        cc.loader.load(wordUrl, function (error, image) {
            if (!error) {
                wordNode.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(image);
                wordNode.opacity = 255;
            }
        });
    },

    animFinish: function animFinish() {
        var nowLane = this.target.showWordFinish();
        //获取碰撞的物品消失
        var collisionNode = this.node.getChildByName(nowLane);
        if (collisionNode) {
            collisionNode.opacity = 0;
        }
    }

    // called every frame, uncomment this function to activate update callback
    // update: function (dt) {

    // },
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=WordManager.js.map
        